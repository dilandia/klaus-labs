# Arquiteto de Agentes · o que tem neste zip

Presente da Portaria do Klaus Labs. Versão 1.3, novembro de 2026.

Comece pelo PDF `Arquiteto-de-Agentes-Guia.pdf`. Ele tem o passo a passo de cada plataforma e o prompt completo no fim.

| Onde você vai usar | Arquivo | Observação |
|---|---|---|
| Qualquer chat (colar na conversa) | `ARQUITETO-system-prompt.md` | Copie o que está entre `=== INÍCIO ===` e `=== FIM ===` |
| Projeto do Claude | `claude-projeto.md` | O prompt completo cabe nas instruções do projeto |
| Projeto do ChatGPT | `chatgpt.md` | Instruções curtas + o prompt completo enviado como arquivo |
| GPT personalizado | `chatgpt.md` (opção B) + `instrucoes-compactas-8000.md` | Desde agosto de 2026, só contas Business, Enterprise e Edu criam GPT novo |
| Skill do Gemini | `gemini-skill.md` | Se o Gemini recusar o prompt pelo tamanho, use a versão compacta |
| Claude Code, Hermes, OpenBot | pasta `arquiteto-de-agentes` + `skill-instalar.md` | A pasta tem o `SKILL.md` pronto |

Travou? Poste a dúvida com um print. Se você está na comunidade, use o canal Socorro Técnico.
